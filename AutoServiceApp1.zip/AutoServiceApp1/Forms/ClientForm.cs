﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoServiceApp1
{
    public partial class ClientForm : Form
    {
        private int clientId;
        private string connectionString = "Server=star6sql2;Database=master;User Id=user64;Password=94696;";

        public ClientForm(int id)
        {
            InitializeComponent();
            clientId = id;
            LoadAppointments();
            LoadServices();
        }

        private void LoadAppointments()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT a.id, s.ServiceName, a.AppointmentDate, a.Status
                                 FROM appointments a
                                 JOIN services s ON a.ServiceId = s.id
                                 WHERE a.ClientId = @ClientId";

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.SelectCommand.Parameters.AddWithValue("@ClientId", clientId);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewClientAppointments.DataSource = table;
            }
        }

        private void LoadServices()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT id, ServiceName FROM services", conn);
                DataTable table = new DataTable();
                adapter.Fill(table);

                comboBoxServices.DataSource = table;
                comboBoxServices.DisplayMember = "ServiceName";
                comboBoxServices.ValueMember = "id";
            }
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            if (dateTimePickerAppointment.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Нельзя записаться на прошедшую дату.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(@"INSERT INTO appointments (ClientId, ServiceId, AppointmentDate, Status) 
                                                  VALUES (@ClientId, @ServiceId, @Date, 'Ожидается')", conn);
                cmd.Parameters.AddWithValue("@ClientId", clientId);
                cmd.Parameters.AddWithValue("@ServiceId", comboBoxServices.SelectedValue);
                cmd.Parameters.AddWithValue("@Date", dateTimePickerAppointment.Value);
                cmd.ExecuteNonQuery();
            }

            LoadAppointments();
            MessageBox.Show("Вы успешно записались.");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (dataGridViewClientAppointments.CurrentRow != null)
            {
                int appointmentId = Convert.ToInt32(dataGridViewClientAppointments.CurrentRow.Cells["id"].Value);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM appointments WHERE id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", appointmentId);
                    cmd.ExecuteNonQuery();
                }

                LoadAppointments();
                MessageBox.Show("Запись отменена.");
            }
        }
    }
}