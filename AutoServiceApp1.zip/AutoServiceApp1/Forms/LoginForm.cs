﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoServiceApp1
{
    public partial class LoginForm : Form
    {
        // Строка подключения к вашей БД
        private string connectionString = "Server=star6sql2;Database=master;User Id=user64;Password=94696;";

        public LoginForm()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string email = textBoxEmail.Text.Trim();
            string password = textBoxPassword.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, введите Email и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Проверка клиента
                    string queryClient = "SELECT * FROM clients WHERE Email = @Email AND passwords = @Password";
                    using (SqlCommand cmd = new SqlCommand(queryClient, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            string name = reader["FullName"].ToString();
                            MessageBox.Show($"Добро пожаловать, клиент {name}!", "Успешная авторизация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            reader.Close();
                            // Здесь можно открыть форму клиента
                            return;
                        }
                        reader.Close();
                    }

                    // Проверка мастера
                    string queryMaster = "SELECT * FROM masters WHERE Email = @Email AND passwords = @Password";
                    using (SqlCommand cmd = new SqlCommand(queryMaster, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            string name = reader["FullName"].ToString();
                            MessageBox.Show($"Добро пожаловать, мастер {name}!", "Успешная авторизация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            reader.Close();
                            // Здесь можно открыть форму мастера
                            return;
                        }
                        reader.Close();
                    }

                    // Неверные данные
                    MessageBox.Show("Неверный Email или пароль.", "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка подключения: " + ex.Message);
                }
            }
        }

        private void textBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}